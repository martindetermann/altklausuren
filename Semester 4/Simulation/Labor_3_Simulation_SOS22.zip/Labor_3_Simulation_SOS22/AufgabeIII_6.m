% SoSe 2022 Simulation
%
% Gruppe A09         
% Determann, Martin, 70474565
% Pietz, Jannis,     70471684
%
% Aufgabe: Labor 3, Aufgabe 3_6 Diagramm der Funktion Fr(ẋ-Vb)

clear,clc;
% Zahlen sind irrelevant, da dieses Diagram nur der Veranschaulichung einer 
% Theoretischen Funktion dient.
s=-1:0.001:1;
Fr=-sign(s);
plot(s,Fr);
% x-Achse definieren, beschriften
xticks([-1 -0.5 0 0.5 1]);
xticklabels({'-∞','ẋ<Vb','ẋ=Vb','ẋ>Vb','+∞'});
xlabel('ẋ-Vb');
% y-Achse definieren, beschriften
yticks([-1 0 1]);
yticklabels({'-1∙μFn','0∙μFn','1∙μFn'});
ylabel('Fr(ẋ-Vb)=-μFnsign(ẋ-Vb)')
figure(1);
