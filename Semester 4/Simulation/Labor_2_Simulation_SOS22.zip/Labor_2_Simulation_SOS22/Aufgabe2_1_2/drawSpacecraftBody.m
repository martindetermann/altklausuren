%Simulation SoS 2022
%Gruppe A09
%Labor_2, Datei�bersicht
%Determann, Martin	70474565
%Pietz, Jannis		70471684
%�bersicht der enthaltenen Dateien

function handle = drawSpacecraftBody(V,F,patchcolors,...
                                     pn,pe,pd,phi,theta,psi,...
                                     handle,mode)
    V = rotate(V', phi, theta, psi)'; % rotate spacecraft
    V = translate(V', pn, pe, pd)'; % translate spacecraft
    % transform vertices from NED to XYZ (for matlab rendering)
    R = [...
        0, 1, 0;...
        1, 0, 0;...
        0, 0, -1;...
    ];
    V = V*R;

    if isempty(handle)
       handle = patch('Vertices', V, 'Faces', F,...
       'FaceVertexCData',patchcolors,...
       'FaceColor','flat',...
       'EraseMode', mode);
    else
        set(handle,'Vertices',V,'Faces',F);
        drawnow
    end
end

