% SoSe 2022 Simulation
%
% Gruppe A09         
%        Determann, Martin, 70474565
%        Pietz, Jannis,     70471684
%
% Aufgabe: Labor 3, Aufgabe III.3.5
% Version: 27.04.2022 

%Definition der numerischen Konstanten
Ra=0.5;
La=1;
c=10;
J=5;
K=20;