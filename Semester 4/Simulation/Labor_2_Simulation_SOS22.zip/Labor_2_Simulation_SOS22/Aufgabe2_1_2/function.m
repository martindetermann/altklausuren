%==========================================================================
% Drawing the Spacecraft time dependent
%==========================================================================
function drawSpacecraft(uu,V,F,patchcolors)
    % process inputs to function
    pn = uu(1); % inertial North position 
    pe = uu(2); % inertial East position
    pd = uu(3); 

    phi = uu(4); % roll angle 
    theta = uu(5); % pitch angle 
    psi = uu(6); % yaw angle 
    t = uu(7); % time 
    % define persistent variables 
    persistent spacecraft_handle;

    % first time function is called, initialize plot and persistent vars
    if t==0
        figure(1), clf
        spacecraft_handle = drawSpacecraftBody(V,F,patchcolors,...
                                               pn,pe,pd,phi,theta,psi,...
                                               [],'normal');
        title('Spacecraft')
        xlabel('East')
        ylabel('North')
        zlabel('-Down')
        view(32,47) % set the vieew angle for figure
        axis([-10,10,-10,10,-10,10]);
        hold on
    % at every other time step, redraw base and rod
    else
        drawSpacecraftBody(V,F,patchcolors,...
                           pn,pe,pd,phi,theta,psi,...
                           spacecraft_handle);
    end
end

%==========================================================================
% drawSpacecraft
% return handle if 3rd argument is empty, otherwise use 3rd arg as handle
%==========================================================================