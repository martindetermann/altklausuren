% SoSe 2022 Simulation
%
% Gruppe A09         
%        Determann, Martin, 7474565
%        Pietz,     Jannis, 70471684
%
% Aufgabe: Labor 2, Aufgabe 2_6
% Version: 28.03.2022 



%Eingabeparameter für AufgabeII6.slx:
%Parameter
R1=1e3;
R2=10e3;
C1=10e-6;
C2=1e-6;


%Variablen für AufgabeII6_1.slx
K1=(R1*C1*R2*C2)^-1;
K2=((R2*C2+R1*C1+R1*C2)/(R1*C1*R2*C2));

%out = sim("AufgabeII_6.slx");



