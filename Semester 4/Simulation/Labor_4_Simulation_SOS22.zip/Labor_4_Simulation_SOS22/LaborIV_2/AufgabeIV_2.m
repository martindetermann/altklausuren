%Simulation SoS 2022
%Gruppe A09
%Labor_2, Dateiübersicht
%Determann, Martin	70474565
%Pietz, Jannis		70471684
%Uebertragungsfunktion
clc;clear;
l=1;
g=10;
k=10;
theta=1;
m=1;
a=0.5;
lambda=3;

%Aufgabenteil b)
phi=-pi/3;

%Aufgabenteil c)
phi_1=pi/3;


%Aufgabenteil d)
figure (1)
plot (Ode1(:,1), Ode1(:,2), Ode14x(:,1), Ode14x(:,2),Ode1be(:,1), Ode1be(:,2),Ode2(:,1), Ode2(:,2),Ode3(:,1), Ode3(:,2),Ode4(:,1), Ode4(:,2),Ode5(:,1), Ode5(:,2),Ode8(:,1), Ode8(:,2))

ldg=legend('Ode1','Ode14x','Ode1be','Ode2','Ode3','Ode4','Ode5','Ode8')
title(ldg, 'Loeser:')
title ('Verschiedene Loeser')

%Aufgabenteil f)

[A,B,C,D]=linmod('AufgabeIV_2_f_1');

%Aufgabenteil i)
s=tf('s');

P=1/(s^2+3*s+12.5);
figure(2)
pzmap(P)

