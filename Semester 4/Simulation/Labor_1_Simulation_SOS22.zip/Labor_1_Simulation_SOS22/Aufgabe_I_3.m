%Simulation SOS 2022
%Gruppe A09
%Labor 1, Aufgabe 3
%Determann, Martin, 70474565
%Pietz, Jannis, 70471684
%Gedämpfte Schwingung

w=0.5;
s=[0,0.25,1,1.5];
w=1.5;