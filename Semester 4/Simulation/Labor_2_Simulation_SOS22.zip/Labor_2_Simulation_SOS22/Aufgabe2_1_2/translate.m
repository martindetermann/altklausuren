%Simulation SoS 2022
%Gruppe A09
%Labor_2, Datei�bersicht
%Determann, Martin	70474565
%Pietz, Jannis		70471684
%�bersicht der enthaltenen Dateien

function XYZ = translate(XYZ, pn, pe, pd)
    XYZ = XYZ + repmat([pn;pe;pd],1,size(XYZ,2));
end