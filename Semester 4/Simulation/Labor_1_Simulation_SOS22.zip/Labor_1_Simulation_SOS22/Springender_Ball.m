%Simulation SOS 2022
%Gruppe A09
%Labor 1, Springender Ball
%Determann, Martin, 70474565
%Pietz, Jannis, 70471684
%Springender Ball Modell
g=9.81; m=1; d=10; c=6000;
