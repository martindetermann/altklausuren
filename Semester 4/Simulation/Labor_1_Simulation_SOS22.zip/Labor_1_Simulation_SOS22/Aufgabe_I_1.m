%Simulation SOS 2022
%Gruppe A09
%Labor 1, Aufgabe 1
%Determann, Martin, 70474565
%Pietz, Jannis, 70471684

%Aufgabe a)
A=[3,-6.4,9;-6,1,-5;17,-3,7;];
b=[20;-0.25;41.35;];
A\b
b/A

%Aufgabe b)
C=[2,i,0.5;0.5,2,7;1,-0.25,-4i;];
d=[2+2i;13i;3;];
linsolve(C,d)
mldivide(C,d)
x=C\d

%Aufgabe c)
x=[3,1,7,9,6,2,8,5,6,4,2];
A=[2,11,8;1,7,3;3,9,4;];
x(2: 3.4: 12)
A(2:3,2:3)
x(12: -3: 1)
A(:)
x(2:end-1)
A(:,2)=[]