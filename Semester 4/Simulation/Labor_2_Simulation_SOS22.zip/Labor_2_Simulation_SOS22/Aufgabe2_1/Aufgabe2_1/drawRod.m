function rod_handle = drawRod(y, theta, L, gap, height, rod_handle, mode)
  X = [y, y+L*sin(theta)];
  Y = [gap+height, gap + height + L*cos(theta)];
  if isempty(rod_handle) 
      rod_handle = plot(X,Y,'g','EraseMode', mode);
  else
  set(rod_handle,'XData',X,'YData',Y);
  end

end