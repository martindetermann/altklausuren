% SoSe 2022 Simulation
%
% Gruppe A09         
%        Determann, Martin, 70474565
%        Pietz, Jannis,     70471684
%
% Aufgabe: Labor 3, Aufgabe III.3
% Version: 11.04.2022 
clc;clear;
%Pole und Nullstellen der untenliegenden Funktion soll bestimmt werden.
%P(s)=(s^2-16)/(s^5+2s^4+s^3)


%Eingabe als rationale Funktion
s=tf('s');

%Aufgabenteil 1
%Implementieren der Übertragungsfunktion
P=(s^2-16)/(s^5+2*s^4+s^3);

%Werte aus der Übertragungsfunktion G
b1=[1 0 -16];%Zaehler
a1=[1 2 1 0 0 0];%Nenner
%Konvertiert Übertragsfkt. Parameter in NS-Pol-Gain Form
[z, p, k]=tf2zp(b1,a1);

%Konvertiert NS-Pol-Gain Form in Zustandsraumdarstellung
[A1,B1,C1,D1] = zp2ss(z,p,k);

%Plotten des Pol-Nulstellen-Diagramms der Ursprünglichen, und der
%zurück konvertierten Funktion, um diese zu vergleichen.
grid on;
figure(1); %benennt die erste Ausgabe
pzmap(P); %Darstellung der Pole und Nullstellen in der z Ebene


%Aufgabenteil 2
%Übertragungsfunkion des anderen Systems
G=(s+3)/(s^2+3*s+2);

%Werte aus der Übertragungsfunktion G
b=[0 1 3];%Zaehler
a=[1 3 2];%Nenner
%Konvertiert Übertragsfkt. Parameter in NS-Pol-Gain Form
[z1,p1, k1]=tf2zp(b,a);

%Konvertiert NS-Pol-Gain Parameter in State-Space Form
[a1, b1, c1, d1]=zp2ss(z1,p1,k1);

%Konvertiert Übertragungs Parameter in State-Space Form
%A = Systemmatrix, B = Eingangsmatrix, C=Ausgangsmatrix, D=Durchgangsmatrix
[A, B, C, D]=tf2ss(b,a);

%Konvertiert State-Space Form in Übertragungsfunktion
[n, d]=ss2tf(A,B,C,D);
tf(n,d)
