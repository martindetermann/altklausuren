%Simulation SoS 2022
%Gruppe A09
%Labor_2, Dateiübersicht
%Determann, Martin	70474565
%Pietz, Jannis		70471684
%Übersicht der enthaltenen Dateien

function rod_handle = drawRod(y, theta, L, gap, height, rod_handle, mode)
  X = [y, y+L*sin(theta)];
  Y = [gap+height, gap + height + L*cos(theta)];
  if isempty(rod_handle) 
      rod_handle = plot(X,Y,'g','EraseMode', mode);
  else
  set(rod_handle,'XData',X,'YData',Y);
  end

end