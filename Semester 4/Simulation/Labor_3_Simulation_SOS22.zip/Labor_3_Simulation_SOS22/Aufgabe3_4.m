% SoSe 2022 Simulation
%
% Gruppe A09         
%        Determann, Martin, 70474565
%        Pietz, Jannis,     70471684
%
% Aufgabe: Labor 3, Aufgabe III.3.4
% Version: 26.04.2022 
clc;clear;
%Eingabe als rationale Funktion
s=tf('s');

w=1;
u=1;

%Implementieren der Übertragungsfunktion
G=(w^2)/(s^2+2*u*w*s+w^2);

%Werte aus der Übertragungsfunktion G
b=[0 0 w^2];%Zaehler
a=[1 2*u*w w^2];%Nenner
%Konvertiert Übertragsfkt. Parameter in NS-Pol-Verstärkung Form
[z, p, k]=tf2zp(b,a)

figure(1);
step(G);

%Plotten des Pol-Nulstellen-Diagramms
figure(2); %benennt die erste Ausgabe
pzmap(G); %Darstellung der Pole und Nullstellen in der z Ebene


%Zweiter Aufgabenteil
w1=4;
u1=-0.1;

G1=(w1^2)/(s^2+2*u1*w1*s+w1^2);

%Werte aus der Übertragungsfunktion G
b1=[0 0 w1^2];%Zaehler
a1=[1 2*u1*w1 w1^2];%Nenner
%Konvertiert Übertragsfkt. Parameter in NS-Pol-Verstärkung Form
[z1, p1, k1]=tf2zp(b1,a1)

%Plotten des Pol-Nulstellen-Diagramms
figure(3); %benennt die erste Ausgabe
pzmap(G1); %Darstellung der Pole und Nullstellen in der z Ebene

figure(4);
step(G1);
