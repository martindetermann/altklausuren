% SoSe 2022 Simulation
%
% Gruppe A09         
%        Determann, Martin, 70474565
%        Pietz, Jannis,     70471684
%
% Aufgabe: Labor 2, Aufgabe 2_5
% Version: 28.03.2022 

%Eingabeparameter: 
p = 28;
sigma = 10;
beta = 2.666;

out = sim("AufgabeII_5.slx");

%Simulation
figure(1)
%plot(out.ScopeData.time, out.ScopeData.signals(1).values) 
plot3(out.ScopeData.signals(1).values, out.ScopeData.signals(2).values, out.ScopeData.signals(3).values,'-', 'color','red')
xlabel('X')
ylabel('Y')
zlabel('z')
grid on


