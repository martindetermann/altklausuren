%Simulation SOS 2022
%Gruppe A09
%Labor 1, Übung 2
%Determann, Martin, 70474565
%Pietz, Jannis, 70471684
%Feder_Masse_Dämpfer System
m=1; d=0.2; c=1.1;
