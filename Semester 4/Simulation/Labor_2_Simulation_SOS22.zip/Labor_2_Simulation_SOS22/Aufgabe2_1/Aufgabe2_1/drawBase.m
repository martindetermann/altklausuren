function base_handle = drawBase(y, width, height, gap, base_handle, mode)
  X = [y-width/2, y+width/2, y+width/2, y-width/2];
  Y = [gap, gap, gap+height, gap+height];
  if isempty(base_handle)
      base_handle = fill(X,Y,'m','EraseMode', mode);
  else
  set(base_handle,'XData',X,'YData',Y);
  end
end

